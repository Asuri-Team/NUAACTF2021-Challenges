#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "indcpa.h"
#include "randombytes.h"
#include "fips202.h"
#include "base64.h"

static void pke_enc(uint8_t c[KYBER_INDCPA_BYTES],
                    const uint8_t m[KYBER_INDCPA_MSGBYTES],
                    const uint8_t pk[KYBER_INDCPA_PUBLICKEYBYTES])
{
  unsigned char  kr[2*KYBER_SYMBYTES];                                     /* Will contain key, coins */
  unsigned char buf[2*KYBER_SYMBYTES];

  randombytes(buf, KYBER_SYMBYTES);
  sha3_256(buf, buf, KYBER_SYMBYTES);                                        /* Don't release system RNG output */

  sha3_256(buf+KYBER_SYMBYTES, pk, KYBER_PUBLICKEYBYTES);                    /* Multitarget countermeasure for coins + contributory KEM */
  sha3_512(kr, buf, 2*KYBER_SYMBYTES);

  indcpa_enc(c, m, pk, kr+KYBER_SYMBYTES);                              /* coins are in kr+AKCN_SYMBYTES */
}

int main(void)
{
  uint8_t pk[KYBER_INDCPA_PUBLICKEYBYTES];
  uint8_t sk[KYBER_INDCPA_SECRETKEYBYTES];
  uint8_t c[KYBER_INDCPA_BYTES];
  // uint8_t m1[KYBER_INDCPA_MSGBYTES];
  uint8_t m2[KYBER_INDCPA_MSGBYTES];

  // char b64_pk[4 * (KYBER_INDCPA_PUBLICKEYBYTES / 3 + 1) + 1];
  // char b64_sk[4 * (KYBER_INDCPA_SECRETKEYBYTES / 3 + 1) + 1];
  // char b64_c[4 * (KYBER_INDCPA_BYTES / 3 + 1) + 1];


  char b64_pk[] = "ThdZS8V3O+u4l5G1zip6w/xIJLJXBpN1MGfP4jWtGICV2RgskepIRCsmoQTHRQRvLuJQ9AJXgWEhv9rANHkWRFdN3mSw2Lo3hoUWcagrBFyo0yuopEwRiXgX4mS091M9BFGmreZirvgDK9vE5GV0DVNI0hJza3EtOIoN7gU0MmFBwYRs45l4jGucZzjINjcSRRCBrfMftQBcdJdN9hDJN4l+/0pz69cQTax1wItyI4KUR+meS/LC9WNi6UpCxDofr1yab8lxjRRDxoam+BPEYcY2uWpVKZHOAOABHFdUGoIWDJllq0wMqnBfmLC3V9MXOUhMvpYN5qNJ6pk5qtTOMpjOqcwh+tE0TpSiw9B781I3RbyPf3WqLzFdLKKDM8VJnKqNvJW3mftF7lqOOuN4+1KSZjBxlyJq1dQjiBs0EjZHnmIdXliimToFLFRQLKc/DqQEIqCxxhqo4YaCESg4aJQC7bO4bNR38eab61IQuSluQRA33gIKmuGJLxaQKww1FlUprOqKCRJ5qJgxF8xmyecy0tAn3Ha8mjDB7vmg5HyqEsMSD8SYWYaEjaMc6UGBa5exS7WX3kiZnwmQ8HYOorIbNwcMo/BLMmCI4eERc4ZesQwSgPeO8XdVDVgX9wSCqoq84hquIjOTRdhDb+TLewtBqoM78vm2yDKIqsV7rigJzueV0WI0YdpE87sC+FAdBdND2utxEjEQRRacutg2qZLGSidD9kgD2hs/5YXH5vqFnBJadnZ7Nat6YMJcoWNh7cyPUrCH6eehCDcw9BkMI2a6wuYeiFMR8gTHl3xpu4fFNak39lStMLaWKCcOoRZ4tVgwxgKUHPxKbPafUAsup4hJaRA6XwgbsNfEBOYWEWcpCYtlxpy/y8gUHQs4osdkHpBD2gc9hSC+FktnnLZFgLVkwRIHO+KwNICwadeEI3CG45VkBROagto4oGMW6IkyzTOUdwR/H5iRqBRY5/En6UYvGTieUiu+KsyoJWws+1oyfTtk88OA2oWU2xgXHpaWmbYk/6IgL7FI6Ug5gArK3vGZubmPttG2GsmxfHd1RIIsSFYVHXycIUO6HEWkjlly65sKLJgY/qtS3TJzmXJGPLgPdPmRzIWDLaIGpyNuQDYo+GaIVrNa4vArZrlZ1kHCodFuqBWk0XcPm+eva/xbaWrKl/HG6GpdFvYwHBBu2Sk9l9O7eWaiPHyvz3zKX/Fb/dmZTrUIeKxkk9UTkVkSayJ4tZc7gtkKJsGCpRqUUyAkopB4tUINokKhZDZ2ASYeUIN7Q7Y1AvNFwuY4mmpvrscUitGVYBmT9zGXmptQ1+GUpuos70HLdVxLTbYDPFhjs7abaNtil1c5iqyO7DLIkRtcNazPboshyzzMyRd4aJZyjdsOHAVIVlySibMnnVIY5zHAJUgaCtk0DpCXgkw6l0dep7OFGvsRjgXEUeudm2Ib8KlG+nbD4ABGA7SOPTbBH9LBUNOhrWpkDHNcGMACttk5XrCGrvmn3qKqyfyY5WtbD0JoeniPYBp5YlE4msZ3EkQVNaP7qf9FEP4xSnOXf8BMToB11ubUKXuAQW9cd1w=";

  char b64_sk[] = "6hF6LeIAQBclaCdoWaMYVmtHPTembelGyAsP3yu19LCDdzhBLJigBeW/wSJqxsApJVqTvzBWh+urowROaZgRIEE/DVOY5ZUnfyNn0UmIWuaIXWgCUxQ/w1pYcMtkKJAmizc9eFhomSNB61WvlzQDoUy4p5Y5C/cY4kyC9wt0z8kyDdIj/WhZ2+ZEDVoLdrA/SecuNPjDR1MQrJhU8atzEjVqBKwMUxMNUtqhRstVcKRUvwiasxDEHLsj7HlnVjOPrwYKYztKhPwJedCgbidv4QJGOqE0jDlhyTR1dqqPvYyqUAyj/PceLNJZKAd21dYo0wGMXLeFAsp84jxWU+QFEvhX0vEP64gmwndz4tFoSAHNqgowRPly5rJ9vbUy+VTN50hGECJKT8vKCDrFDVgWZHQTgWxnTndPV3gpw3oY0MN1L8y57UItnutVwVI8axGiJ7RbSrHD5ek5MyarvZpuOLMWITnFQJMSsQAwzEqRZCl0SIw4ywYSv3BaGNamOENNUphZOMKLTUoVjhRZeiDI3ZCphRCxxgV8cdCMLdXMujuzfqe2tDq7fNOK/tyM1gesfJxnhwgzLBBfA2BXNpsGEBCuBZqMYHZlCleJwuRYgzk5JAvN1dJHKeuoRHMu7PFeLYS5z0nEjCZaz2etFAjJTkKmfggjNmQmBohcErdAx9oUsTJQ7akCM4KGr7BLSoUiJTx+qRqb6LFOSpOWPOop8QVXbMulpNlMnFYghXY9F4u3LOu15YNiPycjLrI2VtF0g7SB/MjP7UVvOqmsX9NAK6qQI8gbkCeOnTQutVQO9ppRfAG+8QI1KORm10uTs0o6tTla29YglpBUQNRgf+PPPEF8jrIu5hAXm3d7mRZ4j2VIXRMGRFGhyCU101xcL/CIPAhYV1MxUGss87cDIFpYBIO8M/uSjWgvchyAarl/7TkXpsAKm/sBngCYXywvLgOLW+e13BBiJRAXJ7jFFAVDeGtFX9ggQNFOtQnPQ5lMCDapSNUcopaAJ2PPQjeRg0R4JBHJMlRTjwSNDFtbE2EEi/eFsEZ3UrRctaMi1aXCAVtqs6CJdLxQYmOgPlTF0lBeLPqq73MFDnZ+DbitNimJ2+oVGeIjvcoDuxeajuwenENg49s7xYtg1WugIHaVI7F08RhRCvfPVmTCVZZ0cLMBF1MpoqCMgyttyxBfI7JNsowoU7eSUKQrYMya3rOeSIki65Yw06pgXOuzK/Z/uAl2KdlJNgR89uKHzMCEezYQkXMwYdENtuRLyvW21VzJrtpPEDLL7Qs7MkAhlFZ1zLZLbZSVOUVGJ0wFb8I4bLRIfMKhu0EQoaOn/mGxJ7GyOYdJDUiMhSg4OJi9KoUjrxNWBhYknXdgD0O9/DEVG/UrbcRjj4FW6duJ4vZ8rIBIWhkrVphMNDptvdCGLmrCP8Ivf+dM38gbHFa90Ug7T+hMdRxVZNs66Pibj6xYFgTQ1pqiynEbtiiA5/OedQuy79hD5lun8lxsQTsb97Q08NVo5+dDJhwvjEFKwhpNcshNWYgC";

  char b64_c[] = "w47YJG7nlgIt0aNz2Nuo4LEjqK3osfLBJdULPp4XZw/R14jpuyYq3HxeKiMkJURtOI6xkJf2B7n9GRYFw8ooWyH+siCgNFmaB1zd+0pwxjBAKgP0DPW0ZEHa8nI3+rtYV0QIMd6pJl8LSbFdt9o3rLxjBKAoB2kN8Ek8VYSzUaGt49PwJpQHsaCW+K/8KNej+2odzujsEHZr6zxI+ZEXrMf/2tObgUKy6YLnfPLCZoBnwWZtbguLYuOD2iiBXvDqEc68btnAm87L5DjwL7GtRLeCHFGpDjXHOvj8LXtYmKUT5WApgeCXuU4Ox+tOTSkhdiDFXSqdbJwh5p8cWkerDutt/OrTamcoMeezx2bJPmfpvB6JSrzqNYVXT+aWhTV02da+58zit3/5i6s2UtjhUYAQmHmjDD9zDXMmzkpIGVuZ5VVx45Es7/KaHm7Uwn6h+ua9SBSkXCdzyaj2TIy95I6W3F0Oxe9ntg+hbzrEs1+K7Lt6npVmzJLNPEAP9J5rMTaP90V0HE9ZXiAp8MxkZBl4eUa/OlTybhjLMKT1iRX6Ls+xR9GiZv0uuDEv6MAZlNWb/Zxo4ajAuY0Myix71U/9IpeDn0cqlr3zq26zt6nf+/yXBhZq93Ir7dp7x2HXeERP3Ul0lx9gvOmpVSgqwHTV/hRx5BpeS41zzW5sqbq5lvvN308adEFi+cN04Ii8birrxSfZyHZl1hbsIzeKdqd0YV/ez5WHyoKHYpa3KTIo3dAmM1lPxNx82xlX7wjEYKyHQ+b599GwV/jDRB0Pkw5WKNUpF9m2iYpKq0Ac0NfAo5DXVR9OvHfDCkOG2RBlgXgaae4qlTPjt1ZGfgjGzea4cbBmV9GBpR648IsbDejaeMLMSrgOlPURwf4GZ0orTnvAjIGvoru8R2EjAdx4eM6meL4Rp0X41hc7HR60DKUUAGPZyf5igg3yJZEwGQOphbGgVWJceeEGdVnyWMic7vNVEqrpLvnbARBatu49YTZ/Uurw+CsRetpMFEovwkCABumNbKwDeZp4bvdAXWJuwMhfqdnKP78R6HD/Xv6CJ/L+Ao8q1ifbYBaFt5KqT7BB4priXv8l5uhK66/XzOpznfdIONv4p4ecv2Y7pZZwz38iMpr9wHd/V+EUf6Vhynf4k/tDHtAZgbPyIng1he78bJyfouItZlZEw0jFv8pLzqsVMpAlKR+5RPCOg9+Ez+IpXbAi4wDsfbg9P+3ZgrxYubXT2bnte9fv9QkgrQyoQH7/rDXhZCbhgJ4EjW5M3aLr/wfAHA4CJxJOCZmpFnlCAWhQobYbklQ70U/PIjAWdAss/m4ARelg05MEvPEqRNAF6jaKSv76rYh8Xnw1trRwDgAD7reSxYIYTtVlTg1z872yc2sQRk/YNLat85MtPGyaAxT+zVup9kufu0nY5vCqlfnLfGOnlNVBv4ygVp+4r+0=";

  b64tobin(pk, b64_pk);
  b64tobin(sk, b64_sk);
  b64tobin(c, b64_c);

  // indcpa_keypair(pk, sk);

  // bintob64(b64_pk, pk, KYBER_INDCPA_PUBLICKEYBYTES);
  // bintob64(b64_sk, sk, KYBER_INDCPA_SECRETKEYBYTES);

  // printf("-----BEGIN PUBLIC KEY-----\n");
  // printf("%s\n", b64_pk);
  // printf("-----END PUBLIC KEY-----\n");

  // printf("-----BEGIN PRIVATE KEY-----\n");
  // printf("%s\n", b64_sk);
  // printf("-----END PRIVATE KEY-----\n");


    // randombytes(m1, KYBER_INDCPA_MSGBYTES);
    char flag[] = "flag{b138c574d2039fc2}";
    // pke_enc(c, m1, pk);

    // bintob64(b64_c, c, KYBER_INDCPA_BYTES);
    // printf("-----BEGIN CIPHERTEXT-----\n");
    // printf("%s\n", b64_c);
    // printf("-----END CIPHERTEXT-----\n");

    indcpa_dec(m2, c, sk);
    printf("flag: %s\n", flag);
    printf("m2: %s\n", m2);

    // if(memcmp(flag, m2, KYBER_INDCPA_MSGBYTES)) {
    //   printf("Error: msg mismatch\n");
    // } else {
    //   printf("Correct\n");
    // }

  return 0;
}
