## MLWE Challenge

scheme: CRYSTALS-Kyber.CPAPKE
parameter set: Kyber768

Just decrypt and get the flag.